package game_of_life;

import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.*;


public class ParallelCellularAutomata
{

  public static void main(String[] args) throws InterruptedException
  {

    //ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();
    ExecutorService executor = Executors.newCachedThreadPool();

    for(int size = 100; size <= 1_000; size+=50) {
      System.out.println(size + "; " + runGame(size, 10, executor));
    }

    executor.shutdown();
  }



  public static long runGame(int size, int runs, ExecutorService executer) throws InterruptedException
  {
    long duration = 0;

    FieldValue[] from = new FieldValue[size];
    FieldValue[] to   = new FieldValue[size];

    for(int i=0; i <runs; i++) {
      initRandom(from);

      // Executed when the barrier is tripped
      Runnable barrierAction = () -> {
        copy(to, from);
      };
      CyclicBarrier barrier = new CyclicBarrier(size, barrierAction);
      CountDownLatch latch = new CountDownLatch(size+1);

      long start = System.currentTimeMillis();
      for (int index = 0; index < size; index++) {
        CellTask task = new CellTask(100, index, from, to, barrier, latch);
        executer.execute(task);
      }

      latch.countDown();
      latch.await();
      long end = System.currentTimeMillis();
      duration += (end - start);
    }

    return duration/runs;
  }
  
  private static void print(FieldValue[] field) 
  {
    for (FieldValue c : field)
    {
      System.out.print(c);
    }
    System.out.println();
  }
  
  private static void copy(FieldValue[] from, FieldValue[] to)
  {
    System.arraycopy(from, 0, to, 0, from.length);
  }
  
  private static void initRandom(FieldValue[] field)
  {
    Arrays.fill(field, FieldValue.W);
    Random rd = new Random();
    for (int i = 0; i < 20; i++)
    {
      field[rd.nextInt(field.length)] = FieldValue.B;
    }
  }
}
