import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public class o2_StructuredConcurrency {
    public static void main(String[] args) throws Exception {
        System.out.println("Hallo");
        System.out.println("---------");
        try (ExecutorService e = Executors.newVirtualThreadPerTaskExecutor()) {
            e.submit(() -> System.out.println("1"));
            e.submit(() -> System.out.println("2"));
        }
        System.out.println("---------");

        TimeUnit.SECONDS.sleep(2);
        System.out.println("done");
    }
}
