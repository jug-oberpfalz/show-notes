import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public class o1_Creation 
{
    public static void main(String[] args) throws Exception 
    {
        System.out.println("Hallo");
        System.out.println(Thread.currentThread().isVirtual());

        Thread.startVirtualThread(() -> {
            System.out.println("Hello World from Virtual Thread");
            System.out.println(Thread.currentThread().isVirtual());
        });

        Runnable task = () -> {
            System.out.println("Hello World from Virtual Thread");
            System.out.println(Thread.currentThread().isVirtual());
        };
        Thread vthread= Thread.ofVirtual().start(task);

        ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();
        executor.execute(task);

        ThreadFactory factory = Thread.ofVirtual().factory();
        Thread fthread= factory.newThread(task);
        fthread.start();

        TimeUnit.SECONDS.sleep(2);
        System.out.println("done");
    }
}
