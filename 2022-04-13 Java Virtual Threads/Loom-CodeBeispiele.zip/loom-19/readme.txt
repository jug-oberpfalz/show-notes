Beispiele wurden auf Basis folgender 
Version erstellt:

Build 19-loom+5-429 (2022/4/4)
Windows/x64

https://jdk.java.net/loom/