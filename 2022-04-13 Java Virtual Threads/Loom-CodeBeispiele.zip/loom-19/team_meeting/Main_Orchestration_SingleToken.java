package team_meeting;

import team_meeting.util.ListFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


/*
 * An orchestration solution 
 *
 * This corresponds to a "token ring" solution.
 * One of the group members takes the role of a leader.
 * The leader sends a suggestion to its neighbor. If a member has the received value
 * in its list it forwards the value to his neighbor.
 * If not it goes to the next possible value and sends this value to 
 * his neighbor.
 * 
 * If the leader gets the same value from is neighbor it knows that
 * all members confirm his value. Then it sends a "end"-token to
 * signal the members that a value was found.
 */

public class Main_Orchestration_SingleToken
{
  static class GroupMember implements Runnable
  {
    // Value to signal end of search
    private static final Integer poissonInteger = Integer.valueOf(-1);

    // One of the group has to be the leader (director)
    private final boolean isLeader;
    
    private final List<Integer> numberList;
    private final String name;
    private final BlockingQueue<Integer> exchangeQueue;

    // A group member knows only his (right) neighbor
    // Thats define the direction of the message flow
    private GroupMember neighbour;

    public GroupMember(String name, boolean leader, List<Integer> numberList)
    {
      this.name = name;
      this.numberList = numberList;
      this.isLeader = leader;
      this.exchangeQueue = new ArrayBlockingQueue<>(1);
    }

    public void setNeighbour(GroupMember neighbour)
    {
      this.neighbour = neighbour;
    }

    @Override
    public void run()
    {
      int index = 0;
      Integer number = this.numberList.get(index);

      try
      {
        while (true)
        {
          if (this.isLeader)
          {
            // send to neighbor
            this.neighbour.exchangeQueue.put(number);
            
            // read from neighbor (blocks until a value is available)
            Integer receivedNumber = this.exchangeQueue.take();

            // Checks if the value has changed
            if (receivedNumber.equals(number))
            {
              // Each member confirms the value
              // Send a termination token to the neighbor and stop
              this.neighbour.exchangeQueue.put(GroupMember.poissonInteger);
              break;
            }
            else
            {
              // The value has changed. Move to the next possible value
              while (number < receivedNumber)
              {
                index++;
                number = this.numberList.get(index);
              }
              number = this.numberList.get(index);
            }
          }
          else
          {
            // read from neighbour
            Integer receivedNumber = this.exchangeQueue.take();

            // Check if a comman value was found
            if (receivedNumber == GroupMember.poissonInteger)
            {
              this.neighbour.exchangeQueue.put(GroupMember.poissonInteger);
              break;
            }

            // The value has changed. Move to the next possible value
            while (number < receivedNumber)
            {
              index++;
              number = this.numberList.get(index);
            }
            number = this.numberList.get(index);

            // send value to neighbour
            this.neighbour.exchangeQueue.put(number);
          }
        }
      }
      catch (InterruptedException exce)
      {
        exce.printStackTrace();
      }

      // comment out during benchmark
      if( this.isLeader )
        System.out.println(name + " --> " + number);
    }
  }

  public static void main(String[] args) throws Exception
  {
    System.out.println("Main_Choreograpy_SingleToken");
    
	
    for (int len = 10; len <= 100; len += 10 )
    {
      long elapsedTime = 0;
      for (int i = 0; i < 5; i++)
      {
        long duration = test(len);
        elapsedTime += duration;
      }
      System.out.println( len + ";" + elapsedTime/5 );
    }
  }

  public static long test(final int len) throws Exception
  {
    List<GroupMember> members = new ArrayList<>();

    // Creating a ring of persons
    // The first person is the leader
    for (int i = 0; i < len; i++)
    {
      List<Integer> list = ListFactory.generateDistinctIntegerList(100_000, 3_111_111, 2_000_000);
      GroupMember member = new GroupMember("A" + i, i == 0, list);
      members.add(member);
    }
    for (int i = 0; i < len; i++)
    {
      members.get(i).setNeighbour(members.get((i + 1) % len));
    }

    long start = System.currentTimeMillis();

    try(  ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor() )
    //try( ExecutorService executor = Executors.newCachedThreadPool() )
    {
      for (int i = 0; i < len; i++)
      {
        executor.submit(members.get(i));
      }
    }

    long end = System.currentTimeMillis();
    return (end - start);
  }
}
