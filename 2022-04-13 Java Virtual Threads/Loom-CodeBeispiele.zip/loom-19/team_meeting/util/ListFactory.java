package team_meeting.util;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public final class ListFactory
{
   private ListFactory() {}
   
   private static Random rand = new Random();
   
   public static List<Integer> generateDistinctIntegerList(int len, int commonItem)
   {
     Set<Integer> set = new HashSet<>();
     
     // add commonItem
     set.add(commonItem);
     
     while( set.size() <= len )
     {
       int nextItem = rand.nextInt(Integer.MAX_VALUE);
       set.add(nextItem); 
     }
     
     Integer[] array = set.toArray(new Integer[set.size()]);
     Arrays.parallelSort(array);
     
     List<Integer> result = Arrays.asList(array);
     
     return result;
   }
   
   public static List<Integer> generateDistinctIntegerList(int len, int commonItem, int max_value)
   {
     assert( len <= max_value );
     
     Set<Integer> set = new HashSet<>();
     
     // add commonItem
     set.add(commonItem); 
     
     while( set.size() <= len )
     {
       int nextItem = rand.nextInt(max_value);
       set.add(nextItem); 
     }
     
     Integer[] array = set.toArray(new Integer[set.size()]);
     Arrays.parallelSort(array);
     
     List<Integer> result = Arrays.asList(array);
     
     return result;
   }
}
