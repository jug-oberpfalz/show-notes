

public class Demo1
{
    public static void main(String[] args) throws InterruptedException
    {
        ContinuationScope scope = new ContinuationScope("demo");

        Continuation myContinuation = new Continuation(scope, () -> {
            int i = 0;
            i++;

            System.out.println("Continuation : " + i + " ->" + Thread.currentThread() );
            // Unmount thread
            Continuation.yield(scope);

            i++;
            System.out.println("Continuation : " + i + " ->" + Thread.currentThread() );
			// Unmount thread
            Continuation.yield(scope);

            i++;
            System.out.println("Continuation : " + i + " ->" + Thread.currentThread() );
			// Unmount thread
            Continuation.yield(scope);
            System.out.println("Continuation : done i = " + i);
        });

        int i = 0;
        i++;

        System.out.println("main : " + i + " ->" + Thread.currentThread() );
        myContinuation.run();
        
        i++;
        System.out.println("main : " + i + " ->" + Thread.currentThread() );
        myContinuation.run();

        i++;
        System.out.println("main : " + i + " ->" + Thread.currentThread() );
        myContinuation.run();

        i++;
        System.out.println("main : " + i + " ->" + Thread.currentThread() );
        myContinuation.run();
		
		
        System.out.println("main done" + Thread.currentThread() );

    }

}
