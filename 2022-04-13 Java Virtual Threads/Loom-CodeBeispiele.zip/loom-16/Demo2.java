

public class Demo2
{
    public static void main(String[] args) throws InterruptedException
    {
        ContinuationScope scope = new ContinuationScope("demo");

        Continuation myContinuation = new Continuation(scope, () -> {
            int i = 0;
            i++;

            System.out.println("Continuation : " + i + " ->" + Thread.currentThread() );
            // Unmount thread
            Continuation.yield(scope);

            i++;
            System.out.println("Continuation : " + i + " ->" + Thread.currentThread() );
			// Unmount thread
            Continuation.yield(scope);

            i++;
            System.out.println("Continuation : " + i + " ->" + Thread.currentThread() );
			// Unmount thread
            Continuation.yield(scope);
            System.out.println("Continuation : done i = " + i);
        });

        Thread t;
        int i = 0;
        i++;

        System.out.println("main : " + i + " ->" + Thread.currentThread() );
        t = new Thread( myContinuation::run );
        t.start();
        t.join();

        i++;
        System.out.println("main : " + i + " ->" + Thread.currentThread() );
        t = new Thread( myContinuation::run );
        t.start();
        t.join();

        i++;
        System.out.println("main : " + i + " ->" + Thread.currentThread() );
        t = new Thread( myContinuation::run );
        t.start();
        t.join();

        i++;
        System.out.println("main : " + i + " ->" + Thread.currentThread() );
        t = new Thread( myContinuation::run );
        t.start();
        t.join();
		
		
        System.out.println("main done" + Thread.currentThread() );

    }

}
