package game_of_life;

public enum FieldValue
{
  B('x'), W('-');
  
  private final char c;
  
  FieldValue(char c)
  {
    this.c =  c;
  }
  

  @Override
  public String toString()
  {
    return String.valueOf(c);
  }
}
