import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;

public class Demo4 {

    static class Task implements Runnable
    {
        final String name;
        final ContinuationScope scope;

        Task(String name, ContinuationScope scope)
        {
            this.name = name;
            this.scope = scope;
        }

        @Override
        public void run() {

            int counter = 0;
            System.out.println( name + " Part 1 : " + counter );
            Continuation.yield(scope);
            counter++;
            System.out.println( name + " Part 2 : " + counter );
            Continuation.yield(scope);
            counter++;
            System.out.println( name + " Part 3 : " + counter );
            Continuation.yield(scope);
            counter++;
            System.out.println( name + " Finished : " + counter );

        }
    }

    public static void main(String[] args) throws Exception
    {
        final ContinuationScope scope1 = new ContinuationScope("Scope 1");
        final ContinuationScope scope2 = new ContinuationScope("Scope 2");

        Task task1 = new Task("Task 1", scope1);
        Task task2 = new Task("Task 2", scope2);

        // Continuations are executed by virtual threads
        Continuation task1Continuation = new Continuation( scope1, task1 );
        Continuation task2Continuation = new Continuation( scope2, task2 );

        try( ExecutorService executor = Executors.newVirtualThreadExecutor() )
        {
            System.out.println("=== Start ===");
            System.out.println("--> Step 1");
            executor.submit( task1Continuation::run ).get();
            executor.submit( task2Continuation::run ).get();

            System.out.println("--> Step 2");
            executor.submit( task1Continuation::run ).get();
            executor.submit( task2Continuation::run ).get();

            System.out.println("--> Step 3");
            executor.submit( task1Continuation::run ).get();
            executor.submit( task2Continuation::run ).get();
        }

        System.out.println("done");
    }
}
