import java.time.Instant;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.LockSupport;

public class Demo5
{
    public static void main(String[] args)
    {
        AtomicInteger counter = new AtomicInteger(0);

        System.out.println("Start");
        Runnable doNothing = () -> {
            try {
                counter.incrementAndGet();
                TimeUnit.SECONDS.sleep(3);  // Blocking
            }
            catch(Exception e) {}
        };

        long start = System.currentTimeMillis();

        //try( ExecutorService executor = Executors.newCachedThreadPool() )
        try( ExecutorService executor = Executors.newVirtualThreadExecutor() )
        {
            for(int i=0; i < 1_000; i++)
            {
                executor.execute( doNothing );
            }
        }
        System.out.println("done in " + (System.currentTimeMillis() - start));
        System.out.println("Count " + counter.get() );
    }
}
