

public class Demo3
{
    public static void main(String[] args) throws InterruptedException
    {
        ContinuationScope scope = new ContinuationScope("demo");

        Continuation myContinuation = new Continuation(scope, () -> {
            int i = 0;
            i++;

            System.out.println("Continuation : " + i + " ->" + Thread.currentThread() );
            // Unmount the actual carrier thread
            Continuation.yield(scope);

            i++;
            System.out.println("Continuation : " + i + " ->" + Thread.currentThread() );
			// Unmount the actual carrier thread
            Continuation.yield(scope);

            i++;
            System.out.println("Continuation : " + i + " ->" + Thread.currentThread() );
			// Unmount the actual carrier thread
            Continuation.yield(scope);
            System.out.println("Continuation done i = " + i);
        });


        int i = 0;
        i++;

        System.out.println("main : " + i + " ->" + Thread.currentThread() );
        Thread.startVirtualThread( myContinuation::run ).join();

        System.out.println("main : " + i + " ->" + Thread.currentThread() );
        Thread.startVirtualThread( myContinuation::run ).join();

        System.out.println("main : " + i + " ->" + Thread.currentThread() );
        Thread.startVirtualThread( myContinuation::run ).join();

        System.out.println("main : " + i + " ->" + Thread.currentThread() );
        Thread.startVirtualThread( myContinuation::run ).join();
		
		
        System.out.println("main done" + Thread.currentThread() );

    }

}
